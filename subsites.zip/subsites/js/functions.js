
function openlogin(){


document.getElementById('login_popup').style.display="block";
document.getElementById('foreground').style.display="block";

}


function closelogin(){


document.getElementById('login_popup').style.display="none";
document.getElementById('foreground').style.display="none";

}

function displaypage(){


document.getElementById("loading").style.display="none";


}

function clearsearch(){

    document.getElementById('searchfield').value="";
    document.getElementById('searchfield').focus();

}

