function clearsearch(){

    document.getElementById('searchfield').value="";
    document.getElementById('searchfield').focus();

}



$(document).ready(function(){
    $("#dropdownbackground,#drop-btn").click(function(){
        $(".dropdown").slideToggle("fast");
         $("#dropdownbackground").slideToggle("fast");
    });
});

$(document).ready(function(){
    $("#options,#close-option,#sidenavbackground").click(function(){
        $("#mySidenav").slideToggle("fast");
        $("#sidenavbackground").slideToggle("slow");
    });
});



$(document).ready(function(){

    $("#srch-btn,#close-searchbar").click(function(){
        $("#searchbar").slideToggle("fast");
        clearsearch();
    
        
    });
});

$(document).ready(function(){
    $("#foreground").click(function(){
        $("#login_popup").slideToggle("fast");
        $("#foreground").slideToggle("fast");
    });
});

$(document).ready(function(){
    $(".quicklooktoggle").click(function(){
        $("#quicklook").slideToggle("fast");
        
    });
});
