<?php    
include 'functions.php';


$url=$_GET['q'];

$a=previewlogo($url);

echo $a;

?>