<?

include 'functions.php';
session_start();
include 'server_login.php';
$conn=server_login();

$name=$_SESSION['Email'];
		$sql="SELECT * FROM faveroit WHERE email_id='$name'";
		$result=mysqli_query($conn,$sql);

		$num=mysqli_num_rows($result);

		$fab=array($num);

		if($num){
                ?>
     <br><br>           
<div class="container-fluid">
<div class="container-fluid site-row">
	<h2>Bookmarks</h2>

	
<div class="row ">

<?php

			while($var=mysqli_fetch_array($result)){

				printsiteinfo($var);


}
?>
	</div>
</div>

<?php
}

?>