<?php

function mailtoemail($to,$message){

			require("class.phpmailer.php");
			$mail = new PHPMailer();

			$mail->IsSMTP();
			$mail->Host = "smtp.gmail.com";

			$mail->SMTPAuth = true;
			$mail->SMTPSecure = "ssl";
			$mail->Port = 465;
			$mail->Username = "ddwakar3@gmail.com";
			$mail->Password = "DDwakar@1997";

			$mail->From = "ddwakar3@gmail.com";
			$mail->FromName = "Test Mail";
			$mail->AddAddress($to);

			//$mail->AddReplyTo("mail@mail.com");

			$mail->IsHTML(true);

			$mail->Subject = "Testing Mail ";
			$mail->Body = "$message hello world";
			//$mail->AltBody = "This is the body in plain text for non-HTML mail clients";
			if($mail->Send()){
				return 1;

			}
			else{
				return 0;
			}

}


function time_diff($t1){//   to find present date- t1

	//echo $t1.",";

		$date=explode(" ",$t1);

		$ad=$date['0'];
		$cd=date("y-m-d");
		$cd = array("20",$cd);
		$cd=implode("", $cd);

		//echo $cd.",";
		
		$at=$date['1'];

		//echo $at;
		//echo " ";
		//echo date("h:m:s");
		$at=explode(":", $at);

		$ch=date("H");
		$cm=date("i");
		$cs=date("s");
		//echo date("H:i:s");
		//echo "---".$ch.":".$cm.":".$cs."---";
		$ch=$ch+5;
		$cm=$cm-30;
		


		$ad=date_create($ad);
		$cd=date_create($cd);

		$diff=date_diff($cd,$ad)->format('%d');

		$time=$diff.' Days ago';

		if($diff==0){

			if($at['0']==$ch){

				if($at['1']==$cm){

						return "Just now";

								}
				else{
					$time=$cm-$at['1'];

					$time=$time.' Minutes ago';

					return $time;
					}
				}

			else{

				$time=$ch-$at['0'];

				$time=$time.' Hours ago';

				return $time;

				}
}

		return $time;



}

function previewlogo($domainname){


		include 'simple_html_dom.php';

		$html= file_get_contents("http://$domainname");

		
		$start=0;
		$temp=1;

		while($temp){

		  $a=strpos($html, "<link",$start);

		  $aa=strpos($html, "icon");

		  if($aa-$a>70){

		$start=$a+6;

		continue;

		  }

		$temp=0;
		  $c=substr($html, $a, 200);

		  $d=strpos($c,"href");

		  $e=substr($c, $d,100);

		  $e=explode("\"", $e);

		  $g=$e['1'];

		  	$dd=strpos($g,"ttp");
		  	if(!$dd){
		  		$g = array("http://","$domainname/","$g");
		  		$g=implode("",$g);
		  	}

		  }

		  return $g;
		}


  function findcategory($domainname){


		$html= file_get_contents("https://fortiguard.com/webfilter?q=$domainname&version=8");


		  $aa=strpos($html, "<h4 class=\"info_title\">Category:");

		  $bb=strpos($html, "</h4>",$aa);

		  $cc=substr($html,$aa+33,$bb-$aa-33);

	
		return $cc;
  }


  function finddescription($domainname){


		$html= file_get_contents("https://www.google.com/search?ei=S97ZW4yNNpPHrQGP14PQCg&q=$domainname&oq=hackerrank&gs_l=psy-ab.3..35i39k1j0l2j0i67k1j0l3j0i67k1j0j0i67k1.4827.8216.0.8612.10.10.0.0.0.0.360.1173.2-2j2.4.0..2..0...1.1.64.psy-ab..6.4.1168...0i131k1j0i10k1.0.ldaUXhOSF2c");

		  $aa=strpos($html, "https://en.wikipedia.org");

		  $bb=strpos($html, "&",$aa);


		  $cc=substr($html,$aa,$bb-$aa);

		  $html1=file_get_contents($cc);

		  $aa=strpos($html1, "<p><b>");

		  $bb=strpos($html1, "</p>",$aa);

		  $cc=substr($html1,$aa+6,$bb-$aa-6);

		  return $cc;
  }

function printsiteinfo($var){
?>
<script type="text/javascript" src="../js/ajax_functions.js"></script>
<div class="col-xs-3 site-info">
			<div ><a target="_blank" href="http://www.<?php echo $var['domain_name']; ?>" >
				<img class="logo" src="<?php echo $var['logo_src'];?>"></a>
				
			</div>
			<div class="container-fluid">	
				<div class="row">
					<form action="site.php" method="GET" class="col-xs-4">
						<input type="text" style="width:0px;height:0px;" class="invisible" name="domain_name" 
						value="<?php echo $var['domain_name']; ?>">

						<button type="submit" class="btn btn-link btn-lg"><i class="glyphicon glyphicon-exclamation-sign"></i></button>
					</form>
					<span class="col-xs-4"><?php echo trim($var['domain_name'],'.com'); ?></span>
					
						<button value="<?php echo $var['domain_name']; ?>" onclick="addbookmark(this.value)" class="btn btn-link btn-lg"><i class="glyphicon glyphicon-bookmark"></i></button>
			
				</div>
			</div>	
		</div>

<?
}


/*
    function findcategory($domainname){


		$html= file_get_contents("http://sitereview.bluecoat.com/#/lookup-result/$domainname");

		
		
		$start=0;
		$temp=3;

		$category=array("0","0","0");

		 $a=strpos($html, "<h4 class=\"info_title\">Category:",$start);


		while($temp){

		 

		  $aa=strpos($html, "href=\"\">",$a);

		  $bb=strpos($html, "</a>",$a);

		  $cc=substr($html,$aa+8,$bb-$aa+8);

		  $a=$bb+2;

		  $category[3-$temp]=$cc;
}

		$category=implode(" ,", $category);

		return $category;
  }
  */
?>