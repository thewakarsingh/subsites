<div id="sidenavbackground">ugytfvt</div>
<div id="mySidenav">
	  <a href="javascript:void(0)" style="margin-top: -3%; margin-right: 4%;" id="close-option" class="closebtn">></a><br>
	  <span style="color:#ddd; margin-left: 10%; font-size: 30px;">Welcome  <i><?php echo $_SESSION['Name'];?> </i></span><hr style="color: white;">	

	  <a href="php/bookmark.php"><i class="glyphicon glyphicon-bookmark"></i>Bookmarks</a>

	  <a href="tutorials/">Tutorials</a>

	  <a href="suggest.php">Suggest a Website</a>

	  <button onclick="logout()" class="btn btn-danger" style="margin-top: 90%;margin-left: 40%;">Logout</button>					
</div>