<?php

$domain=$_GET['domain'];

session_start();

$email=$_SESSION['Email'];

if (!isset($email)) {
	echo "2";
}

else{
	include 'server_login.php';

	$conn=server_login();

	$query="SELECT * FROM faveroit WHERE domain_name='$domain' AND email_id='$email'";

	$result=mysqli_query($conn,$query);

	$a=mysqli_num_rows($result);

	if($a){
		mysqli_query($conn,"DELETE FROM faveroit WHERE domain_name='$domain' AND email_id='$email'");
		echo "0";
	}

	else{
	$query="INSERT INTO faveroit(domain_name,email_id) VALUES ('$domain','$email')";
	if(mysqli_query($conn,$query))
		echo "1";
	}
}

?>