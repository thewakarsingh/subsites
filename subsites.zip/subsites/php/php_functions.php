<?php

function show_comments($conn,$domain_name){



$sql="SELECT * FROM comments WHERE domain_name='$domain_name'";

$result=mysqli_query($conn,$sql);

while($var=mysqli_fetch_array($result)){
?>
	
	<div><?php echo $var['name']; ?></div>
	<div><?php echo $var['comment']; ?></div>



<?php




}
}

?>