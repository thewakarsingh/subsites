<?php

include 'server_login.php';

$txt=$_GET['q'];

$conn=server_login();

if($txt){
	$domainname="";
$q="SELECT * FROM sites WHERE domain_name like ('%$txt%')";

$result=mysqli_query($conn,$q);

	while ($var=mysqli_fetch_array($result)) {
		$a=$var['domain_name'];
		$domainname.="<div style=\"border:solid 1px #ddd;border-radius:8px;margin:5px;\">$a<a class=\"btn btn-primary\"style=\"float:right;\" href=\"https://www.$a\">Visit Site</a></div>";
		
	}

	echo $domainname;
}

?>