 

<div class="loginpopup panel custompanel">
           <div class="panel-heading">Welcome to login pannel <button onclick="closelogin()" class="close-button">X</button></div>
          
 <div class="panel-body">
      <ul class="nav nav-tabs" data-tabs="tabs">
<li class="active col-xs-6" id="loginbtn"><a href="#login" data-toggle="tab"><span style="font-size:20px;">Login</span></a></li>
<li class="col-xs-6" id="signupbtn"><a href="#signup" data-toggle="tab"><span style="font-size:20px;">Signup</span> </a> </li>

  </ul>

  <div class="tab-content"><br>
      <div class="tab-pane active" id="login">
        <div class="row">
          <div class="col-sm-12">
        <div class="alert alert-info" style="text-align: center;">
          <strong>Login! </strong>Enter your registerd email id and password to login.
         </div>

        <div>
              
             <div class="inner-addon left-addon">
                   <i class="glyphicon glyphicon-user inner-addon"></i>
                   <input type="email" id="email_l" name="email" class="textfield form-control input-md" placeholder="username" required>
              </div>                          
              
             <br> 
             <div class="inner-addon left-addon">
                   <i class="glyphicon glyphicon-lock inner-addon"></i>          
             <input Type="password" id="password_l" class="textfield form-control input" name="password" required placeholder="password">


             
             </div>
             <center>
             <br><span id="loginerror" style="color:red;">
             </span>
             
             <br><br>
             
                <button onclick="logina()" type="submit" class="btn btn-lg btn-success" value="Login" style=" cursor:pointer;">login</button>

                <br><br>

             <span ><a style="text-align:left !important;"  href="forgot password/">Forgot Password?</a></span>
        </center>
      </div>
      </div>
   
    </div>
    </div>

      <div class="tab-pane" id="signup">
        <div class="row">
          <div class="col-sm-12">

            <div class="col-sm-12 alert alert-info" style="text-align: center;">
              <strong>Signup! </strong>Provide follwing details to signup.
            </div>

            <div>
               <div class="inner-addon left-addon">
                 <i class="glyphicon glyphicon-user inner-addon"></i>
                 <input type="text" class="textfield form-control" id="fullname_s" name="name" placeholder="full name">
                      </div><br>

                <div class="inner-addon left-addon">
                 <i class="glyphicon glyphicon-user inner-addon"></i>
                 <input type="email" class="textfield form-control" id="email_s" name="email" required placeholder="email id">
                </div><br>

                <div class="inner-addon left-addon">
                 <i class="glyphicon glyphicon-lock inner-addon"></i>
                 <input type="password" class="textfield  form-control" id="password_s" name="password" required placeholder="password">
                </div><br>
                      
                <div class="text text-danger" id="signuperror" style="text-align: center;"></div><br>
                  <center><button class="btn btn-lg btn-success" onclick="signupa()" value="signup" style="align:center">  signup
                  </button> </center>
             
            </div>
          </div>
      </div>
    </div>
  </div>
</div>
</div>