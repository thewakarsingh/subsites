<div id="mySidenav" class="sidenav">
	  <a href="javascript:void(0)" style="margin-top: -3%; margin-right: 4%;" id="close-option" class="closebtn">></a><br>
	  <h4 style="margin-left: 9px;" >Welcome  <i><?php echo $_SESSION['Name'];?> </i></h4><hr style="color: white;">	

	  <a href="bookmark.php">Bookmarks</a>

	  <a href="tutorials/">Tutorials</a>

	  <a href="suggest.php">Suggest a Website</a>

	  <button onclick="logout()" class="btn btn-danger" style="margin-top: 90%;margin-left: 40%;">Logout</button>					
</div>