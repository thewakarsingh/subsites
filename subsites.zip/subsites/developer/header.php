<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
<link rel="icon" type="images/png" href="images/icon.png"/>
<link rel="stylesheet" href="css/general.css">
<script src="../bootstrap/js/jquery.min.js"></script>
<script src="../bootstrap/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <title>subsites</title></head>
<body>
	<div class="contaier-fluid" style="background-color: #111;">
		<div class="row" >
			<div class="col-sm-3">
				<p style="color: white; padding: 4px;"><a href="home.php">Welcome To Admin Panel</a></p>
				
			</div>
			<div class="col-sm-7" >
				<ul>
					<li><a href="siteentry.php" style=" color:white;font-size: 18px;text-decoration: none;">
						Site Entry &nbsp;&nbsp;

					<a href="sitesearch.php?name=" style=" color:white;font-size: 18px;text-decoration: none;">
						Edit Site&nbsp;&nbsp;

					<a href="homecategory.php" style=" color:white;font-size: 18px;text-decoration: none;">
						Home category.&nbsp;&nbsp;




					</li>



				</ul>
				





			</div>
			<div class="col-sm-2"><a href="index.php">logout</a></div>
		</div>
	</div>
